Component({
  options: {
    styleIsolation: "isolated"
  }
});